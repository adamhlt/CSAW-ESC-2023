# BitsFromBZH Writeup for CSAW ESC 2023

In each folder, you'll find the python script used to solve the challenge, along with instructions on how to use it. Each challenge is supplied with the samples used, if required.

### Team Members

- Adam Henault
- Florian Lecocq
- Axel Gouriou
- Philippe Tanguy (Faculty Supervisor)